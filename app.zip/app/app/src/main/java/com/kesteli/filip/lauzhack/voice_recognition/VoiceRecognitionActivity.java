package com.kesteli.filip.lauzhack.voice_recognition;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.kesteli.filip.lauzhack.R;

public class VoiceRecognitionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_recognition);

//        Speech.init(this, getPackageName());
    }
}




