package com.kesteli.filip.lauzhack;

/**
 * Created by Valemate on 11.11.2017..
 */

public class POJOMain {

    public static final String KEY_MOJ_LOGIN_SHARED_PREFERENCES = "shared_prefs_login";
    public static final String KEY_ID_JA = "id_user2";
    public static final String KEY_IME_JA = "ime_user2";
    public static final String KEY_PREZIME_JA = "prezime_user2";
    public static final String KEY_EMAIL_JA = "email_user2";
    public static final String KEY_INSTRUKCIJE_JA = "instrukcije_user2";
    public static final String KEY_IME_ON = "ime_covjeka";
    public static final String KEY_EMAIL_ON = "email_covjeka";
    public static final String KEY_ID_ON = "id_covjeka";

}
